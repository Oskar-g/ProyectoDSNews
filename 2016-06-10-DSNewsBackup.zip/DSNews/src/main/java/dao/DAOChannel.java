package dao;

import java.util.List;

import modelos.Channel;

public interface DAOChannel {
	public Channel read();

}
