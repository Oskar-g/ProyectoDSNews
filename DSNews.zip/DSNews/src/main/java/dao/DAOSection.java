package dao;

import java.util.List;

import modelos.Section;

public interface DAOSection {
	List<Section> listar();
}
